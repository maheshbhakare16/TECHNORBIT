class Bike
{
    private String B_No = "";
    private String Chessi_No="";
    public void setB_NO(String b_no)
    {
        this.B_No = b_no;
    }
    public void setChessi_no(String chessi_No)
    {
        this.Chessi_No = chessi_No;
    }
    public String getB_NO()
    {
        return this.B_No;
    }
    public String getChessi_no()
    {
        return this.Chessi_No;
    }
}
