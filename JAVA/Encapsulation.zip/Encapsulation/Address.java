class Address
{
    private String add = "";
     public void setAdd(String add)
     {
        this.add = add;
     }
     public String getAdd()
     {
        return this.add;
     }
}
